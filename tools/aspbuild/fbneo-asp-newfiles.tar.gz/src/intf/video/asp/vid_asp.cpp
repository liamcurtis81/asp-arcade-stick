// Video output for the Neo Geo Arcade Stick Pro.
//
// Writes RGB565 straight to /dev/fb0 at the stride the display driver really
// uses, with no SDL surface and no scaler in between. That is the same path
// the SNES, NES and Mega Drive builds on this device use, and it is the reason
// they hold 60fps where RetroArch managed 35: RetroArch goes through an SDL
// surface into a 32bpp framebuffer at two to three times the memory traffic,
// on a chip with no GPU.
//
// The device has two quirks that this file exists to deal with, both learned
// the hard way and both documented in asp_fbout.h and asp_geom.h:
//
//   The driver reports bits_per_pixel 16 AND line_length 5120 for a 1280-wide
//   mode. Those cannot both be true. The hardware reads rows 2560 bytes apart;
//   honouring line_length puts row i on hardware row 2i and shows the top half
//   of the picture stretched over the whole screen.
//
//   The panel is not the shape of the framebuffer. A display that scales
//   1280x720 to fill a 5:4 panel distorts the picture after it leaves the
//   framebuffer, where no software can reach it, so the target rectangle is
//   solved for the shape that comes out right once the panel has had its way.
//
// Both live in asp_screen.cfg so they can be corrected without a rebuild.

#include "burner.h"

// ---------------------------------------------------------------------------
// asp_screen.cfg, read once at startup. Same file and keys as the other three
// emulators on this device, so one place governs all of them.
//
// These have to be defined BEFORE asp_geom.h, which reads them directly -
// its own header comment says as much. Declaring them underneath the include
// compiles everywhere except here, because the other three emulators keep
// them as file-scope globals above their includes.
// ---------------------------------------------------------------------------
static int  asp_fb_mode    = 3;      // 3 = stride is xres*2, the correct one here
static int  asp_inset_x    = 0;
static int  asp_inset_y    = 0;
static int  asp_keep_aspect = 1;
static int  asp_calibrate  = 0;
static int  asp_panel_w    = 5;      // measured: a 1280x1024 monitor
static int  asp_panel_h    = 4;

// asp_geom.h calls this; it has to be declared before the include.
static void asp_read_screen_cfg();

#include "asp_fbout.h"
#include "asp_calib.h"
#include "asp_geom.h"

static unsigned char *asp_buffer = NULL;   // RGB565, what FBNeo draws into
static int asp_buf_w = 0, asp_buf_h = 0;   // in display orientation
static int asp_rotated = 0, asp_flipped = 0;

static void asp_read_screen_cfg()
{
	static int done = 0;
	if (done) return;
	done = 1;

	const char *paths[] = {
		"asp_screen.cfg",
		"/mnt/hdisk/ASPh/hack/bin/fba/asp_screen.cfg",
		"/mnt/udisk/ASPh/hack/bin/fba/asp_screen.cfg",
		NULL
	};
	FILE *fp = NULL;
	for (int i = 0; paths[i] && !fp; i++) fp = fopen(paths[i], "r");
	if (!fp) {
		fprintf(stderr, "asp: no asp_screen.cfg, using built-in defaults "
			"(fb_mode=%d panel=%d:%d)\n", asp_fb_mode, asp_panel_w, asp_panel_h);
		return;
	}

	char line[256];
	while (fgets(line, sizeof(line), fp)) {
		char *p = line;
		while (*p == ' ' || *p == '\t') p++;
		if (*p == '#' || *p == '\n' || *p == '\0') continue;
		char *eq = strchr(p, '=');
		if (!eq) continue;
		*eq = '\0';
		char *key = p, *val = eq + 1;
		for (char *q = key + strlen(key) - 1; q >= key && (*q==' '||*q=='\t'); q--) *q = '\0';
		while (*val == ' ' || *val == '\t') val++;

		if      (!strcmp(key, "fb_mode"))  asp_fb_mode  = atoi(val);
		else if (!strcmp(key, "inset_x"))  asp_inset_x  = atoi(val);
		else if (!strcmp(key, "inset_y"))  asp_inset_y  = atoi(val);
		else if (!strcmp(key, "calibrate"))asp_calibrate= atoi(val);
		else if (!strcmp(key, "aspect"))   asp_keep_aspect = (strncmp(val,"fill",4) != 0);
		else if (!strcmp(key, "panel_aspect")) {
			int a = 0, b = 0;
			if (sscanf(val, "%d:%d", &a, &b) == 2 && a > 0 && b > 0) {
				asp_panel_w = a; asp_panel_h = b;
			}
		}
	}
	fclose(fp);
	fprintf(stderr, "asp: fb_mode=%d inset=%d,%d aspect=%s panel=%d:%d calibrate=%d\n",
		asp_fb_mode, asp_inset_x, asp_inset_y,
		asp_keep_aspect ? "keep" : "fill", asp_panel_w, asp_panel_h, asp_calibrate);
}

// ---------------------------------------------------------------------------
// Present
// ---------------------------------------------------------------------------
static void asp_present()
{
	int ox, oy, dw, dh;
	if (!asp_buffer) return;
	if (!asp_fb_first_frame_setup()) return;

	asp_target_rect_fb(&ox, &oy, &dw, &dh);
	asp_fb_present((const unsigned short *)asp_buffer,
		asp_buf_w, asp_buf_h, asp_buf_w, ox, oy, dw, dh);
}

// ---------------------------------------------------------------------------
// VidOut
// ---------------------------------------------------------------------------
static int AspInit()
{
	int gw = 0, gh = 0, xa = 0, ya = 0;

	asp_read_screen_cfg();

	if (!bDrvOkay) return 0;

	BurnDrvGetVisibleSize(&gw, &gh);
	BurnDrvGetAspect(&xa, &ya);
	asp_rotated = (BurnDrvGetFlags() & BDF_ORIENTATION_VERTICAL) ? 1 : 0;
	asp_flipped = (BurnDrvGetFlags() & BDF_ORIENTATION_FLIPPED)  ? 1 : 0;

	// FBNeo's blitter rotates into the buffer when the image dimensions are
	// given swapped, so from here on everything is in display orientation.
	nVidImageDepth = 16;
	nVidImageBPP   = 2;
	nVidImageWidth  = asp_rotated ? gh : gw;
	nVidImageHeight = asp_rotated ? gw : gh;
	nVidImagePitch  = nVidImageWidth * nVidImageBPP;

	SetBurnHighCol(nVidImageDepth);

	asp_buf_w = nVidImageWidth;
	asp_buf_h = nVidImageHeight;

	free(asp_buffer);
	asp_buffer = (unsigned char *)calloc(1, (size_t)asp_buf_w * asp_buf_h * nVidImageBPP);
	if (!asp_buffer) {
		fprintf(stderr, "asp: could not allocate a %dx%d RGB565 buffer\n",
			asp_buf_w, asp_buf_h);
		return 1;
	}

	nBurnBpp   = nVidImageBPP;
	nBurnPitch = nVidImagePitch;
	pVidImage  = asp_buffer;

	/* Measure the framebuffer here, not on the first drawn frame. Startup
	 * logging is closed before the emulation loop begins, so a bench run
	 * from the present path reported its result into /dev/null - the same
	 * mistake the evdev probe made. AspInit runs inside DrvInit, while the
	 * log is still open. */
	if (asp_fb_first_frame_setup())
		asp_fb_bench();

	fprintf(stderr, "asp: game %dx%d aspect %d:%d%s%s -> buffer %dx%d RGB565\n",
		gw, gh, xa, ya,
		asp_rotated ? " rotated" : "", asp_flipped ? " flipped" : "",
		asp_buf_w, asp_buf_h);

	return 0;
}

static int AspExit()
{
	asp_fb_close();
	free(asp_buffer);
	asp_buffer = NULL;
	pVidImage  = NULL;
	return 0;
}

static int AspRunFrame(bool bRedraw)
{
	if (!pVidImage) return 1;
	VidFrameCallback(bRedraw);
	return 0;
}

static int AspPaint(int /*bValidate*/)
{
	asp_present();
	return 0;
}

static int AspGetSettings(InterfaceInfo *)
{
	return 0;
}

static int AspScale(RECT *, int, int)
{
	return 0;
}

struct VidOut VidOutAsp = {
	AspInit, AspExit, AspRunFrame, AspPaint, AspScale, AspGetSettings,
	_T("Arcade Stick Pro direct framebuffer")
};
