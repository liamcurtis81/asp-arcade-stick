# Makefile for FBNeo, for use on Raspberry Pi
#
# The first pass makes sure all intermediary targets are present. The second pass updates
# any targets, if necessary. (Intermediary) targets which have their own unique rules
# are generated as required.

unexport

#
#	Flags. Uncomment any of these declarations to enable their function.
#

# Check for changes in header files
ifndef	SKIPDEPEND
DEPEND = 1
endif


#
#	Declare variables
#

# Specify the name of the executable file, without ".exe"
NAME = fbneo

BUILD_X86_ASM=
INCLUDE_AVI_RECORDING=
BUILD_A68K=
UNICODE=


#
#	Specify paths/files
#

objdir	= obj/
srcdir	= src/

include makefile.burn_rules

#
#	Drop the console drivers.
#
#	This build only ever serves the arcade pages: emuinfo.txt points the "fba"
#	entry here, while the Mega Drive, SNES and NES pages each run their own
#	emulator (md_emu.dge, sfc_emu.dge, fc_emu.dge) and the Neo Geo page stays
#	on the stock fba029743. So FBNeo's console drivers are never reachable,
#	and they are the largest objects in the build: d_spectrum 3.7MB, d_gba
#	3.6MB, d_nes 3.0MB, d_megadrive 2.8MB, d_snes 2.6MB, d_msx 1.9MB.
#
#	Removing them is not only tidiness. The bridge that copies files to the
#	card refuses anything over 30MB, and the device has 262MB of RAM with a
#	driver scan at startup that touches every driver's name. Smaller is
#	better on both counts.
#
#	Anything removed here must be checked against the 212 romsets the arcade
#	pages actually list; dep/generated/driverlist.h is the authority on what
#	ended up in the build.
#	Note: d_sms.o has to stay - smsrender.cpp needs SMSPalette from it.
ASP_DROP := d_spectrum.o spectrum.o \
		d_gba.o gba.o \
		d_nes.o nes.o \
		d_megadrive.o d_mdarcbl.o \
		d_snes.o \
		d_msx.o \
		d_coleco.o \
		d_pce.o \
		d_sg1000.o \
		d_channelf.o \
		d_ngp.o

drvsrc := $(filter-out $(ASP_DROP),$(drvsrc))
# Platform-specific
alldir += burner burner/pi burner/sdl dep/libs/libspng dep/libs/lib7z \
		dep/libs/zlib intf intf/video intf/video/scalers intf/video/asp \
		intf/audio intf/audio/sdl intf/input intf/input/pi intf/cd \
		intf/perfcount intf/perfcount/pi dep/generated \
		dep/pi/gles

depobj += cdlist.o \
		\
		conc.o cong.o dat.o gamc.o gami.o image.o ioapi.o misc.o \
		sshot.o state.o statec.o unzip.o zipfn.o \
		\
		adler32.o compress.o crc32.o deflate.o gzclose.o gzlib.o \
		gzread.o gzwrite.o infback.o inffast.o inflate.o inftrees.o \
		trees.o uncompr.o zutil.o \
		\
		spng.o \
		\
		aud_dsp.o aud_interface.o cd_interface.o cd_chd.o inp_interface.o \
		interface.o lowpass2.o  vid_interface.o vid_softfx.o \
		vid_support.o \
		\
		2xpm.o 2xsai.o ddt3x.o epx.o hq2xs.o hq2xs_16.o xbr.o xbr32.o \
		\
		inp_pi.o aud_sdl.o support_paths.o \
		ips_manager.o scrn.o config.o \
		main_pi.o run_pi.o stringset.o bzip.o drv.o media.o inpdipsw.o \
		matrix.o vid_asp.o inputbuf.o replay.o cd_img.o romdata.o crt.o


ifdef INCLUDE_7Z_SUPPORT
	depobj	+= un7z.o 7zArcIn.o 7zBuf.o 7zBuf2.o 7zCrc.o 7zCrcOpt.o \
		7zDec.o 7zFile.o 7zStream.o Alloc.o Bcj2.o Bra.o Bra86.o BraIA64.o \
		CpuArch.o Delta.o LzmaDec.o Lzma2Dec.o Ppmd7.o Ppmd7Dec.o \
		Sha256.o Xz.o XzCrc64.o XzCrc64Opt.o XzDec.o \
		Sha256Opt.o MtDec.o MtCoder.o Lzma2DecMt.o Threads.o
endif

autobj += $(depobj)

ifdef BUILD_X86_ASM
autobj += eagle_fm.o 2xsaimmx.o hq2x32.o hq3x32.o hq4x32.o superscale.o
endif
# End platform-specific




incdir = $(foreach dir,$(alldir),-I$(srcdir)$(dir)) -I$(objdir)dep/generated \
		  -I$(srcdir)dep/pi/include -I$(srcdir)intf/input/sdl \
		  -I$(ASPSYSROOT)/include -I$(ASPSYSROOT)/include/SDL -I$(ASPHDRS)

lib	= -static -L$(ASPSYSROOT)/lib -lstdc++ -lSDL -lpthread -lm -lz -ldl

autdep	= $(depobj:.o=.d)
drvdep	= $(drvsrc:.o=.d)

ifdef	BUILD_A68K
a68k.o	= $(objdir)cpu/a68k/a68k.o
endif

driverlist.h = $(srcdir)dep/generated/driverlist.h
ctv.h	= $(srcdir)dep/generated/ctv.h
toa_gp9001_func.h = $(srcdir)dep/generated/toa_gp9001_func.h
neo_sprite_func.h = $(srcdir)dep/generated/neo_sprite_func.h
cave_tile_func.h = $(srcdir)dep/generated/cave_tile_func.h
cave_sprite_func.h = $(srcdir)dep/generated/cave_sprite_func.h
psikyo_tile_func.h = $(srcdir)dep/generated/psikyo_tile_func.h
pgm_sprite.h = $(srcdir)dep/generated/pgm_sprite.h
build_details.h = $(srcdir)dep/generated/build_details.h

allobj	= $(objdir)cpu/m68k/m68kcpu.o $(objdir)cpu/m68k/m68kops.o \
	  $(foreach file,$(autobj:.o=.c), \
		$(foreach dir,$(alldir),$(subst $(srcdir),$(objdir), \
		$(firstword $(subst .c,.o,$(wildcard $(srcdir)$(dir)/$(file))))))) \
	  $(foreach file,$(autobj:.o=.cpp), \
		$(foreach dir,$(alldir),$(subst $(srcdir),$(objdir), \
		$(firstword $(subst .cpp,.o,$(wildcard $(srcdir)$(dir)/$(file))))))) \
	  $(foreach file,$(autobj:.o=.asm), \
		$(foreach dir,$(alldir),$(subst $(srcdir),$(objdir), \
		$(firstword $(subst .asm,.o,$(wildcard $(srcdir)$(dir)/$(file))))))) \
	  $(foreach file,$(autobj:.o=.rc), \
		$(foreach dir,$(alldir),$(subst $(srcdir),$(objdir), \
		$(firstword $(subst .rc,.o,$(wildcard $(srcdir)$(dir)/$(file)))))))

ifdef BUILD_A68K
allobj += $(a68k.o)
endif

alldep	= $(foreach file,$(autobj:.o=.c), \
		$(foreach dir,$(alldir),$(subst $(srcdir),$(objdir), \
		$(firstword $(subst .c,.d,$(wildcard $(srcdir)$(dir)/$(file))))))) \
	  $(foreach file,$(autobj:.o=.cpp), \
		$(foreach dir,$(alldir),$(subst $(srcdir),$(objdir), \
		$(firstword $(subst .cpp,.d,$(wildcard $(srcdir)$(dir)/$(file))))))) \
	  $(foreach file,$(autobj:.o=.rc), \
		$(foreach dir,$(alldir),$(subst $(srcdir),$(objdir), \
		$(firstword $(subst .rc,.d,$(wildcard $(srcdir)$(dir)/$(file)))))))

autdrv := $(drvsrc:.cpp=.o)

#
#
#	Specify compiler/linker/assembler
#
#

CC	= $(CROSS)gcc
CXX	= $(CROSS)g++

# FBNeo compiles three small generators and then RUNS them to produce headers
# (ctv.h, pgm_sprite.h, m68kops.c/h). Built with the cross compiler those are
# ARM binaries, and the build host cannot execute them - which is exactly the
# "Error 126" this makefile hit. They are self-contained, stdio only, so they
# build for the host with no flags beyond -O2.
#	Do NOT use -mcpu=cortex-a7 here. It tells GCC the chip has the ARMv7
#	integer divide extension, and GCC then emits sdiv/udiv - 1573 of them in
#	one build. This chip does not have it. Its /proc/cpuinfo Features line
#	reads
#	    swp half thumb fastmult vfp edsp neon vfpv3 tls vfpv4
#	with no idiva or idivt, where a real Cortex-A7 lists both. Every game
#	crashed with SIGILL at the first divide, from an unmodified binary.
#
#	-march=armv7-a -mtune=cortex-a7 is the correct pair: ARMv7 instruction
#	selection and A7 scheduling, without assuming hardware divide.
#
#	Build for the CPU this device actually has.
#
#	Everything on this card - the three working emulators and the stock
#	fba029743 - is compiled -march=armv5te with soft float. The device is a
#	Cortex-A7 at 1.308GHz reporting "vfp edsp neon vfpv3 vfpv4". So every
#	binary on it targets a 1998 instruction set and leaves the FPU unused.
#
#	The float side is the lesser half. The bigger cost is that at armv5te GCC
#	must assume an unaligned 16- or 32-bit load traps, so it emits a
#	multi-instruction sequence for each one. Emulators read words out of byte
#	arrays constantly - ROM fetches, tile decodes, sprite lists - and ARMv7
#	does those in a single instruction.
#
#	float-abi is softfp, not hard, deliberately: softfp uses the FPU for
#	arithmetic while keeping the soft-float calling convention, so this still
#	links against the sysroot's static SDL, which is armv5te soft-float and
#	would otherwise be ABI-incompatible.
HOSTCC	?= gcc
HOSTCXX	?= g++
LD	= $(CXX)
AS	= nasm

#LDFLAGS	= -static

CFLAGS = -march=armv7-a -mtune=cortex-a7 -mfpu=neon-vfpv4 -mfloat-abi=softfp -O3 -fomit-frame-pointer -Wno-write-strings \
	   -Wall -Wno-long-long -Wno-sign-compare -Wno-uninitialized -Wno-unused \
	   -Wno-pedantic -Wno-conversion -Wno-attributes -Wno-unused-but-set-variable \
	   -Wno-unused-parameter -Wno-unused-value \
	   -include unistd.h -D_GNU_SOURCE \
	   $(DEF) $(incdir)
	   
CXXFLAGS = -march=armv7-a -mtune=cortex-a7 -mfpu=neon-vfpv4 -mfloat-abi=softfp -O3 -fomit-frame-pointer -Wno-write-strings \
	   -Wall -W -pedantic -Wno-long-long \
	   -Wunknown-pragmas -Wundef -Wconversion -Wno-missing-braces \
	   -Wuninitialized -Wpointer-arith -Winline -Wno-multichar \
	   -Wno-pedantic -Wno-conversion -Wno-attributes -Wno-unused-but-set-variable \
	   -Wno-unused-parameter -Wno-unused-value -Wno-narrowing \
	   $(DEF) $(incdir)

ASFLAGS	=  -O1 -f coff -w-orphan-labels

#       D3DUtils & D3DMath need these
#       DEF     = -Dsinf=\(float\)sin -Dcosf=\(float\)cos -Dasinf=\(float\)asin -Dacosf=\(float\)acos -Dsqrtf=\(float\)sqrt

# FIXME
	DEF	:= -DBUILD_SDL -DBUILD_PI -DBUILD_ASP -DUSE_SPEEDHACKS -DFILENAME=$(NAME) -D__fastcall=

ifdef UNICODE
	DEF	:= $(DEF) -D_UNICODE
endif

ifdef SPECIALBUILD
	DEF	:= $(DEF) -DSPECIALBUILD=$(SPECIALBUILD)
endif

ifdef FASTCALL
	DEF	:= $(DEF) -DFASTCALL
endif

ifdef DEBUG
	DEF	:= $(DEF) -DFBNEO_DEBUG
endif

ifdef ROM_VERIFY
	DEF	:= $(DEF) -DROM_VERIFY
endif

ifdef INCLUDE_7Z_SUPPORT
	DEF := $(DEF) -DINCLUDE_7Z_SUPPORT
endif

ifdef INCLUDE_AVI_RECORDING
	DEF := $(DEF) -DINCLUDE_AVI_RECORDING
endif

ifdef LSB_FIRST
	DEF	:= $(DEF) -DLSB_FIRST
endif

ifdef INCLUDE_LIB_PNGH
	DEF	:= $(DEF) -DINCLUDE_LIB_PNGH
endif

ifdef BUILD_A68K
	DEF	:= $(DEF) -DBUILD_A68K
endif

ifdef BUILD_X86_ASM
	DEF := $(DEF) -DBUILD_X86_ASM
endif

ifdef BUILD_X64_EXE
	DEF := $(DEF) -DBUILD_X64_EXE -DXBYAK_NO_OP_NAMES -DMIPS3_X64_DRC
endif

ifdef	SYMBOL

	CFLAGS   += -ggdb3
	CXXFLAGS += -ggdb3
	ASFLAGS  += -g
	DEF	 := $(DEF) -D_DEBUG

ifdef PROFILE
	CFLAGS	 += -pg
	CXXFLAGS += -pg
else
	CFLAGS	 += -fomit-frame-pointer
	CXXFLAGS += -fomit-frame-pointer
endif

else
	LDFLAGS	 += -s
endif

# For zlib
DEF := $(DEF) -DNO_VIZ -D_LARGEFILE64_SOURCE=0 -D_FILE_OFFSET_BITS=64 -DCHDR_SYSTEM_ZLIB

# For lib7z
ifdef INCLUDE_7Z_SUPPORT
DEF := $(DEF) -D_7ZIP_PPMD_SUPPPORT -D_7ZIP_ST
endif

#
#
#	Specify paths
#
#

vpath %.asm	$(foreach dir,$(alldir),$(srcdir)$(dir)/ )
vpath %.cpp	$(foreach dir,$(alldir),$(srcdir)$(dir)/ )
vpath %.c	$(foreach dir,$(alldir),$(srcdir)$(dir)/ )
vpath %.h	$(foreach dir,$(alldir),$(srcdir)$(dir)/ )
vpath %.rc	$(foreach dir,$(alldir),$(srcdir)$(dir)/ )

vpath %.o 	$(foreach dir,$(alldir),$(objdir)$(dir)/ )
vpath %.d 	$(foreach dir,$(alldir),$(objdir)$(dir)/ )

#
#
#	Rules
#
#

.PHONY:	all init cleandep touch clean

ifeq ($(MAKELEVEL),1)
ifdef DEPEND

all:	init $(drvdep) $(autdep) $(autobj) $(autdrv)
	@$(MAKE) -f makefile.asp -s

else

all:	init $(autobj) $(autdrv)
	@$(MAKE) -f makefile.asp -s

endif
else

all:	$(NAME)

endif

#
#
#	Rule for linking the executable
#
#

ifeq ($(MAKELEVEL),2)

$(objdir)drivers.o:		$(autdrv)
	@echo Linking drivers...
	@$(LD) -r -nostdlib -o $@ $^

$(NAME):	$(allobj) $(objdir)drivers.o
	@echo
	@echo Linking executable... $(NAME)
	@$(LD) $(CFLAGS) $(LDFLAGS) -o $@ $^ $(lib)

ifdef	DEBUG

#	Don't compress when making a debug build

else
ifdef	COMPRESS
	@upx --best $@
endif
endif
endif

ifeq ($(MAKELEVEL),1)
ifdef FORCE_UPDATE
$(build_details.h): FORCE
endif
endif

#
#	Generate the gamelist
#

burn.o burn.d:	driverlist.h

$(driverlist.h): $(drvsrc) $(srcdir)dep/scripts/gamelist.pl
ifdef	PERL
	@$(srcdir)dep/scripts/gamelist.pl -o $@ -l gamelist.txt \
		$(filter %.cpp,$(foreach file,$(drvsrc:.o=.cpp),$(foreach dir,$(alldir), \
		$(firstword $(wildcard $(srcdir)$(dir)/$(file))))))
else
ifeq ($(MAKELEVEL),2)
	@echo
	@echo Warning: Perl is not available on this system.
	@echo $@ cannot be updated or created!
	@echo
endif
endif

#
# Verify if driverlist.h needs to be updated
#

#ifeq ($(MAKELEVEL),1)
#ifdef FORCE_UPDATE
#$(driverlist.h): FORCE
#endif
#endif


#
#	Compile 68000 cores
#

# A68K

ifdef	BUILD_A68K
$(a68k.o):	fba_make68k.c
	@echo Compiling A68K MC68000 core...
	@$(CC) -mconsole $(CFLAGS) $(LDFLAGS) -DWIN32 -Wno-unused -Wno-conversion -Wno-missing-prototypes \
		-s $< -o $(subst $(srcdir),$(objdir),$(<D))/$(<F:.c=.exe)
	@$(subst $(srcdir),$(objdir),$(<D))/$(<F:.c=.exe) $(@:.o=.asm) \
		$(@D)/a68k_tab.asm 00 $(ppro)
	@echo Assembling A68K MC68000 core...
	@$(AS) $(ASFLAGS) $(@:.o=.asm) -o $@
endif

# Musashi

$(objdir)cpu/m68k/m68kcpu.o: $(srcdir)cpu/m68k/m68kcpu.c $(objdir)dep/generated/m68kops.h $(srcdir)cpu/m68k/m68k.h $(srcdir)cpu/m68k/m68kconf.h
	@echo Compiling Musashi MC680x0 core \(m68kcpu.c\)...
	@$(CC) $(CFLAGS) -c $(srcdir)cpu/m68k/m68kcpu.c -o $(objdir)cpu/m68k/m68kcpu.o

$(objdir)cpu/m68k/m68kops.o: $(objdir)cpu/m68k/m68kmake $(objdir)dep/generated/m68kops.h $(objdir)dep/generated/m68kops.c $(srcdir)cpu/m68k/m68k.h $(srcdir)cpu/m68k/m68kconf.h
	@echo Compiling Musashi MC680x0 core \(m68kops.c\)...
	@$(CC) $(CFLAGS) -c $(objdir)dep/generated/m68kops.c -o $(objdir)cpu/m68k/m68kops.o

$(objdir)dep/generated/m68kops.h $(objdir)dep/generated/m68kops.c: $(objdir)cpu/m68k/m68kmake $(srcdir)cpu/m68k/m68k_in.c
	$(objdir)cpu/m68k/m68kmake $(objdir)dep/generated/ $(srcdir)cpu/m68k/m68k_in.c

$(objdir)cpu/m68k/m68kmake: $(srcdir)cpu/m68k/m68kmake.c
	@echo Compiling Musashi MC680x0 core \(m68kmake.c\)...
	@$(HOSTCC) -O2 $(srcdir)cpu/m68k/m68kmake.c -o $(objdir)cpu/m68k/m68kmake


#
#	Extra rules for generated header file ctv.h, needed by ctv.cpp
#

ctv.d ctv.o:	$(ctv.h)

$(ctv.h):	ctv_make.cpp
	@echo Generating $(srcdir)dep/generated/$(@F)...
	@$(HOSTCXX) -O2 $< \
		-o $(subst $(srcdir),$(objdir),$(<D))/$(<F:.cpp=.exe)
	@$(subst $(srcdir),$(objdir),$(<D))/$(<F:.cpp=.exe) >$@

#
#	Extra rules for generated header file toa_gp9001_func.h, needed by toa_gp9001.cpp
#

toa_bcu2.d toa_bcu2.o toa_gp9001.d toa_gp9001.o: $(toa_gp9001_func.h)

$(toa_gp9001_func.h):	$(srcdir)dep/scripts/toa_gp9001_func.pl
	@$(srcdir)dep/scripts/toa_gp9001_func.pl -o $(toa_gp9001_func.h)

#
#	Extra rules for generated header file neo_sprite_func.h, needed by neo_sprite.cpp
#

neo_sprite.d neo_sprite.o: $(neo_sprite_func.h)

$(neo_sprite_func.h):	$(srcdir)dep/scripts/neo_sprite_func.pl
	@$(srcdir)dep/scripts/neo_sprite_func.pl -o $(neo_sprite_func.h)

#
#	Extra rules for generated header file cave_tile_func.h, needed by cave_tile.cpp
#

cave_tile.d cave_tile.o: $(cave_tile_func.h)

$(cave_tile_func.h):	$(srcdir)dep/scripts/cave_tile_func.pl
	@$(srcdir)dep/scripts/cave_tile_func.pl -o $(cave_tile_func.h)

#
#	Extra rules for generated header file cave_sprite_func.h, needed by cave_sprite.cpp
#

cave_sprite.d cave_sprite.o: $(cave_sprite_func.h)

$(cave_sprite_func.h):	$(srcdir)dep/scripts/cave_sprite_func.pl
	@$(srcdir)dep/scripts/cave_sprite_func.pl -o $(cave_sprite_func.h)

#
#	Extra rules for generated header file psikyo_tile_func.h / psikyo_sprite_func.h, needed by psikyo_tile.cpp / psikyo_sprite.cpp
#

psikyo_tile.d psikyo_tile.o psikyosprite.d psikyo_sprite.o: $(psikyo_tile_func.h)

$(psikyo_tile_func.h):	$(srcdir)dep/scripts/psikyo_tile_func.pl
	$(srcdir)dep/scripts/psikyo_tile_func.pl -o $(psikyo_tile_func.h)

#
#	Extra rules for generated header file pgm_sprite.h, needed by pgm_draw.cpp
#

pgm_draw.d pgm_draw.o:	$(pgm_sprite.h)

$(pgm_sprite.h):	pgm_sprite_create.cpp
	@echo Generating $(srcdir)dep/generated/$(@F)...
	@$(HOSTCXX) -O2 $< \
		-o $(subst $(srcdir),$(objdir),$(<D))/$(<F:.cpp=.exe)
	@$(subst $(srcdir),$(objdir),$(<D))/$(<F:.cpp=.exe) >$@


ifeq ($(MAKELEVEL),2)
ifdef DEPEND

include	$(alldep)

endif
endif


#
#	Generic rules for C/C++ files
#
# Note: require init to complete before assembling anything (see "| init" below)
# to avoid parallization issues on fresh builds.
#

ifeq ($(MAKELEVEL),1)

%.o:	%.cpp
	@echo Compiling $<...
	@$(CC) $(CXXFLAGS) -c $< -o $(subst $(srcdir),$(objdir),$(<D))/$(@F)

%.o:	%.c
	@echo Compiling $<...
	@$(CC) $(CFLAGS) -c $< -o $(subst $(srcdir),$(objdir),$(<D))/$(@F)

%.o:	%.asm | init
	@echo Assembling $<...
	@$(AS) $(ASFLAGS) $< -o $(subst $(srcdir),$(objdir),$(<D))/$(@F)

else

%.o:	%.c
	@echo Compiling $<...
	@$(CC) $(CFLAGS) -c $< -o $@

%.o:	%.asm | init
	@echo Assembling $<...
	@$(AS) $(ASFLAGS) $< -o $@

%.o:
	@echo Compiling $<...
	@$(CC) $(CXXFLAGS) -c $< -o $@

endif

#
#	Generate dependencies for C/C++ files
#

ifdef DEPEND

%.d:	%.c
	@echo Generating depend file for $<...
	@$(CC) -MM -MT "$(subst $(srcdir),$(objdir),$(<D))/$(*F).o $(subst $(srcdir),$(objdir),$(<D))/$(@F)" -x c++ $(CXXFLAGS) $< >$(subst $(srcdir),$(objdir),$(<D))/$(@F)

%.d:	%.cpp
	@echo Generating depend file for $<...
	@$(CC) -MM -MT "$(subst $(srcdir),$(objdir),$(<D))/$(*F).o $(subst $(srcdir),$(objdir),$(<D))/$(@F)" -x c++ $(CXXFLAGS) $< >$(subst $(srcdir),$(objdir),$(<D))/$(@F)

%.d:	%.rc
	@echo Generating depend file for $<...
	@$(CC) -MM -MT "$(subst $(srcdir),$(objdir),$(<D))/$(*F).o $(subst $(srcdir),$(objdir),$(<D))/$(@F)" -x c++ $(CXXFLAGS) $< >$(subst $(srcdir),$(objdir),$(<D))/$(@F)

endif

#
#	Phony targets
#

init:

ifdef	DEBUG
	@echo Making debug build...
else
	@echo Making normal build...
endif
	@echo
	@mkdir -p $(foreach dir, $(alldir),$(objdir)$(dir))
	@mkdir -p $(srcdir)dep/generated

cleandep:
	@echo Removing depend files from $(objdir)...
	-@for dir in $(alldir); do rm -f $(objdir)$$dir/*.d; done

touch:
	@echo Marking all targets for $(NAME) as uptodate...
	-@touch $(NAME).exe
	-@touch -c -r $(NAME).exe $(srcdir)/dep/generated/*
	-@for dir in $(alldir); do touch -c  -r $(NAME).exe $(objdir)$$dir/*; done

clean:
	@echo Removing build files...
	-@rm -fr $(objdir) $(ctv.h) $(dep)generated gamelist.txt $(NAME)

ifdef	PERL
	@echo Removing all files generated with perl scripts...
	-@rm -f -r $(app_gnuc.rc) $(driverlist)
endif


#
#	Rule to force recompilation of any target that depends on it
#

FORCE:
